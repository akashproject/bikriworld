
<footer class="footer text-center">
	<strong>Copyright &copy; {{ date('Y') }}
        <a href="{{ env('APP_URL') }}" target="_blank">Medcyclopedia </a></strong>
    <div class="float-right d-none d-sm-inline-block">
        <strong>Developed By <a href="https://weavers-web.com/" target="_blank">Scriptcrown Infotech</a></strong>
    </div>
	All Rights Reserved by <a href="https://wrappixel.com">Medcyclopedia</a>.
</footer>
<!-- <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.0.0-alpha14/js/tempusdominus-bootstrap-4.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.0.0-alpha14/css/tempusdominus-bootstrap-4.min.css" /> -->