<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Pankaj Kumar Jha">
    <!-- CSRF Token -->
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'MoodRx')); ?></title>
    <!-- Scripts -->
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <!-- Styles -->
    <link href="<?php echo e(url('assets/libs/flot/css/float-chart.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/extra-libs/multicheck/multicheck.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('dist/css/style.min.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body class="">

    <!-- Preloader - style you can find in spinners.css -->
    
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    
    <!-- Main wrapper - style you can find in pages.scss -->
    
	<div id="main-wrapper">
		<?php if(true): ?>
			<?php echo $__env->make('includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>			
		<?php endif; ?>
		
		<div class="page-wrapper">
			<?php echo $__env->make('includes.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="container-fluid">
            <!-- Sales Cards  -->           
                <div class="row">
                <?php echo $__env->yieldContent('content'); ?>
                </div>
		    </div>
            <!-- End PAge Content -->
            
		</div>
		<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
<!-- All Jquery -->

<script src="<?php echo e(url('assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/libs/popper.js/dist/umd/popper.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/libs/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/extra-libs/sparkline/sparkline.js')); ?>"></script>
<script src="<?php echo e(url('dist/js/sidebarmenu.js')); ?>"></script>
<script src="<?php echo e(url('dist/js/custom.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/libs/flot/excanvas.js')); ?>"></script>
<script src="<?php echo e(url('assets/libs/flot/jquery.flot.js')); ?>"></script>
<script src="<?php echo e(url('assets/libs/flot/jquery.flot.pie.js')); ?>"></script>
<script src="<?php echo e(url('assets/libs/flot/jquery.flot.time.js')); ?>"></script>
<script src="<?php echo e(url('assets/libs/flot/jquery.flot.stack.js')); ?>"></script>
<script src="<?php echo e(url('assets/libs/flot/jquery.flot.crosshair.js')); ?>"></script>
<script src="<?php echo e(url('assets/libs/flot.tooltip/js/jquery.flot.tooltip.min.js')); ?>"></script>
<script src="<?php echo e(url('dist/js/pages/chart/chart-page-init.js')); ?>"></script>
<script src="<?php echo e(url('dist/js/waves.js')); ?>"></script>
<script src="<?php echo e(url('assets/extra-libs/multicheck/datatable-checkbox-init.js')); ?>"></script>
<script src="<?php echo e(url('assets/extra-libs/multicheck/jquery.multicheck.js')); ?>"></script>
<script src="<?php echo e(url('assets/extra-libs/DataTables/datatables.min.js')); ?>"></script>
<script src="assets/libs/quill/dist/quill.min.js"></script>
<!--Wave Effects -->
<script>
    /****************************************
        *       Basic Table                   *
        ****************************************/
    $('#zero_config').DataTable();
</script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH /home1/scripzwx/adminmed/resources/views/layouts/admin.blade.php ENDPATH**/ ?>