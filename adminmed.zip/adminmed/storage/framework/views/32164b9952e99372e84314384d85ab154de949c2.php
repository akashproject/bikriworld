<?php $__env->startSection('content'); ?>

<div class="col-12">

	<div class="card">

		<form class="form-horizontal" method="post" action="<?php echo e(url('submitinstitutecourse')); ?>" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
			<div class="card-body">
				<h4 class="card-title"> Add Course</h4>
				<?php if($errors->any()): ?>
					<div class="alert alert-danger">
						<ul>
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li><?php echo e($error); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
				<?php endif; ?>

				<div class="form-group row">
					<label for="state" class="col-sm-3 text-right control-label col-form-label">Course Type</label>
					<div class="col-sm-9">
						<select name="course_id" id="course_id" class="select2 form-control custom-select" style="width: 100%; height:36px;">							
							<option value="">Select Course</option>
							<?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($course->id); ?>" > <?php echo e($course->course_name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<select>
					</div>
				</div>	
				<div class="form-group row">
					<label for="course_name" class="col-sm-3 text-right control-label col-form-label">Course name</label>
					<div class="col-sm-9">
						<input type="text" class="form-control" name="course_name" id="course_name" placeholder="Course name Here" >

					</div>

				</div>

				<div class="form-group row">

					<label for="eligibility" class="col-sm-3 text-right control-label col-form-label">Eligibility</label>

					<div class="col-sm-9">

						<input type="text" class="form-control" name="eligibility" id="title" placeholder="Eligibility Here" >

					</div>

				</div>
				<div class="form-group row">

					<label for="duration" class="col-sm-3 text-right control-label col-form-label">Duration</label>

					<div class="col-sm-9">

						<input type="text" class="form-control" name="duration" id="duration" placeholder="Course Duration" >

					</div>

				</div>

				<div class="form-group row">

					<label for="last_enrolment_date" class="col-sm-3 text-right control-label col-form-label">Last enrolment date</label>

					<div class="col-sm-9">

						<input type="text" class="form-control" name="last_enrolment_date" id="title" placeholder="Last enrolment date" >

					</div>

				</div>

				<div class="form-group row">

					<label for="seat" class="col-sm-3 text-right control-label col-form-label">Seat</label>

					<div class="col-sm-9">

						<input type="text" class="form-control" name="seat" id="title" placeholder="Seat Number Here" >

					</div>

				</div>

				<div class="form-group row">

					<label for="fee" class="col-sm-3 text-right control-label col-form-label">Fees</label>

					<div class="col-sm-9">

						<input type="text" class="form-control" name="fee" id="fee" placeholder="Fee Amount" >

					</div>

				</div>

				
						
			</div>

			<div class="border-top">

				<div class="card-body">

					<button type="submit" class="btn btn-primary">Submit</button>
					<input type="hidden"  name="institute_id" value="<?php echo e($institute_id); ?>"  >
				</div>

			</div>

		</form>

	</div>

</div>              

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<!-- ============================================================== -->

<!-- CHARTS -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/scripzwx/adminmed/resources/views/institutes/course-add.blade.php ENDPATH**/ ?>