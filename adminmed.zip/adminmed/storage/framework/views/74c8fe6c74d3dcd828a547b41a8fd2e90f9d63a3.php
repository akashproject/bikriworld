<?php $__env->startSection('content'); ?>

<div class="col-12">

	<?php if($countries): ?>

		<div class="card">

			<div class="card-body">

				<h5 class="card-title">Basic Datatable</h5>

				<div class="table-responsive">

					<table id="zero_config" class="table table-striped table-bordered">

						<thead>

							<tr>

								<th>Name</th>

								<th>Code</th>

								<th>Currency</th>

								<th>Medicaleducation</th>

								<th>Alace of attraction</th>
								<th>Food hobbits</th>
								<th>Culture</th>
								<th>Weather</th>
								<th>How to reach</th>
								<th>Created Date</th>
								<th>Options</th>

							</tr>

						</thead>

						<tbody>

							<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($value->name); ?></td>
								<td><?php echo e($value->code); ?></td>
								<td><?php echo e($value->currency); ?></td>
								<td><?php echo e($value->medicaleducation); ?></td>
								<td><?php echo e($value->about); ?></td>
								<td><?php echo e($value->place_of_attraction); ?></td>
								<td><?php echo e($value->food_hobbits); ?></td>
								<td><?php echo e($value->culture); ?></td>
								<td><?php echo e($value->weather); ?></td>
								<td><?php echo e($value->how_to_reach); ?></td>								
								<td> <?php echo e($value->created_at->isoFormat('MMM DD, YYYY')); ?> </td>
								<td>
									<button type="button" class="btn btn-primary btn-lg">Edit</button>
									<button type="button" class="btn btn-danger btn-lg">Delete</button>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>							

						</tbody>

					</table>

				</div>



			</div>

		</div>

	<?php endif; ?>

</div>                   

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<!-- ============================================================== -->

<!-- CHARTS -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/scripzwx/adminmed/resources/views/country/index.blade.php ENDPATH**/ ?>