<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\User;
use App\Models\Order;
use App\Models\Brand;
use App\Models\Categories;
use App\Models\Question;
use App\Models\Accessories;
use App\Models\Age;
use App\Models\Condition;
use App\Models\SellRequest;
use App\Models\DeviceConfig;
use App\Models\Series;
use App\Models\ProductConfigPrice;


class ProductsController extends Controller
{
    public $_statusOK = 200;
    public $_statusErr = 500;

    public function listProduct(Request $request){
        try {

            
            $requestData = $request->all();
            $products = Product::where('brand_id', $requestData['brand_id'])
            ->where('category_id', $requestData['category_id'])
            ->orderBy('name', 'asc')
            ->get();

            if($requestData['category_id'] == "12"){
                return response()->json($products,$this->_statusOK);
                //return view('vehicle.index',compact('products','brand','user','tobSellingBrands','tobSellingProducts'));
            } else {
                return response()->json($products,$this->_statusOK);
                //return view('product.index',compact('products','brand','user','tobSellingBrands','tobSellingProducts'));
            }
            
            } catch(\Illuminate\Database\QueryException $e){
        }
    }
}
